import Foundation

@MainActor
final class AppCoordinator: ObservableObject {
    enum State: Equatable {
        case booting
        case locked
        case ready
        case updateRequired(V4VersionState)
        case maintenance(V4VersionState?)
        case blocked(V4VersionState?)
        case error(String)
    }

    @Published private(set) var state: State = .booting
    @Published private(set) var config: V4ClientConfig?
    @Published private(set) var packages: [RemotePackage] = []
    @Published private(set) var licenseInfo: LicenseInfo?
    @Published var isWorking = false

    private let secure = SecureStore()
    private let api = V4APIClient()

    private let licenseKeyAccount = "htvantix-v4-license-key"
    private let licenseTokenAccount = "htvantix-v4-license-token"
    private let sessionTokenAccount = "htvantix-v4-session-token"

    var sessionToken: String? {
        secure.load(account: sessionTokenAccount)
    }

    func bootstrap() async {
        guard let savedKey = secure.load(account: licenseKeyAccount), !savedKey.isEmpty else {
            state = .locked
            return
        }
        await activateInternal(key: savedKey, persistKey: false)
    }

    func activate(key: String) async {
        let value = key.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        guard !value.isEmpty else {
            state = .error("กรุณากรอก License Key")
            return
        }
        await activateInternal(key: value, persistKey: true)
    }

    private func activateInternal(key: String, persistKey: Bool) async {
        isWorking = true
        defer { isWorking = false }

        do {
            let redeem = try await api.redeemKey(key)
            let session = try await api.createSession(licenseToken: redeem.licenseToken)

            if persistKey {
                try secure.save(key, account: licenseKeyAccount)
            }
            try secure.save(redeem.licenseToken, account: licenseTokenAccount)
            try secure.save(session.sessionToken, account: sessionTokenAccount)

            licenseInfo = redeem.license

            // Restore the richer client/system status layer. Config is optional
            // for login so a temporary config failure does not lock the owner out.
            config = try? await api.loadClientConfig(sessionToken: session.sessionToken)
            packages = try await api.loadPackages(sessionToken: session.sessionToken)
            state = .ready
        } catch {
            if !persistKey {
                // If a stored key can no longer start a valid V4 session,
                // return to the license screen instead of looping.
                secure.clear(account: licenseTokenAccount)
                secure.clear(account: sessionTokenAccount)
                state = .locked
            } else {
                handle(error)
            }
        }
    }

    func refreshPackages() async {
        guard let token = sessionToken, !token.isEmpty else {
            // Re-bootstrap to obtain a fresh 15-minute session.
            await bootstrap()
            return
        }

        do {
            config = try? await api.loadClientConfig(sessionToken: token)
            packages = try await api.loadPackages(sessionToken: token)
        } catch {
            // Session may have expired. Redeem the saved key and recreate it.
            if let key = secure.load(account: licenseKeyAccount), !key.isEmpty {
                await activateInternal(key: key, persistKey: false)
            } else {
                handle(error)
            }
        }
    }

    func download(_ package: RemotePackage) async throws -> URL {
        guard let token = sessionToken, !token.isEmpty else {
            throw APIError.server(status: 401, code: "SESSION_REQUIRED", client: nil)
        }

        do {
            return try await api.downloadPackage(package, sessionToken: token)
        } catch {
            // One automatic session refresh for an expired V4 session.
            if let key = secure.load(account: licenseKeyAccount), !key.isEmpty {
                await activateInternal(key: key, persistKey: false)
                if let refreshed = sessionToken, !refreshed.isEmpty {
                    return try await api.downloadPackage(package, sessionToken: refreshed)
                }
            }
            throw error
        }
    }

    func signOut() {
        secure.clear(account: licenseKeyAccount)
        secure.clear(account: licenseTokenAccount)
        secure.clear(account: sessionTokenAccount)
        config = nil
        packages = []
        licenseInfo = nil
        state = .locked
    }

    func clearError() {
        if case .error = state { state = .locked }
    }

    private func handle(_ error: Error) {
        if case let APIError.server(_, code, client) = error {
            if let client {
                switch code.uppercased() {
                case "UPDATE_REQUIRED", "VERSION_TOO_OLD":
                    state = .updateRequired(client)
                    return
                case "MAINTENANCE":
                    state = .maintenance(client)
                    return
                case "BUILD_NOT_ALLOWED":
                    state = .blocked(client)
                    return
                default:
                    break
                }
            }
            state = .error(userMessage(for: code))
            return
        }
        state = .error(error.localizedDescription)
    }

    private func userMessage(for code: String) -> String {
        switch code.lowercased() {
        case "device_mismatch": return "คีย์นี้ถูกผูกกับอุปกรณ์อื่น"
        case "expired": return "คีย์หมดอายุแล้ว"
        case "revoked": return "คีย์ถูกปิดใช้งาน"
        case "not_found", "license_invalid": return "ไม่พบ License Key"
        case "bad_request": return "ข้อมูลคีย์หรือข้อมูลอุปกรณ์ไม่ถูกต้อง"
        case "license_session_required": return "เซสชัน License หมดอายุ กรุณาลองใหม่"
        case "server_not_configured": return "ระบบหลังบ้านยังตั้งค่า Session ไม่ครบ"
        case "network": return "เชื่อมต่อระบบคีย์ไม่สำเร็จ"
        case "client_not_configured": return "Client configuration missing"
        case "build_not_allowed": return "Build นี้ยังไม่ได้รับอนุญาตจากระบบ"
        default: return code
        }
    }
}
