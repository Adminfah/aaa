import SwiftUI
import UIKit

// MARK: - Capture protected container
//
// HTVANTIX keeps its UI visible on the device while asking iOS to exclude the
// protected view hierarchy from screenshots, screen recording and screen share.
// The protection is provided by the same secure rendering path UIKit uses for
// secure text fields. This is intentionally isolated here so the rest of the
// SwiftUI app does not need to know about UIKit internals.
//
// Important: Apple does not expose a public "prevent screenshot for any view"
// API. If the secure container cannot be created on a future iOS version, this
// implementation fails closed while an active capture is detected (local black
// cover) instead of leaking the protected UI.

private struct CaptureProtectedContainer<Content: View>: UIViewControllerRepresentable {
    let content: Content
    let captureState: PrivacyShieldState

    init(captureState: PrivacyShieldState, @ViewBuilder content: () -> Content) {
        self.captureState = captureState
        self.content = content()
    }

    func makeUIViewController(context: Context) -> ProtectedHostingController<Content> {
        ProtectedHostingController(rootView: content, captureState: captureState)
    }

    func updateUIViewController(
        _ uiViewController: ProtectedHostingController<Content>,
        context: Context
    ) {
        uiViewController.update(rootView: content)
    }
}

private final class ProtectedHostingController<Content: View>: UIViewController {
    private let hostingController: UIHostingController<Content>
    private let secureTextField = UITextField(frame: .zero)
    private weak var protectedCanvas: UIView?
    private let captureState: PrivacyShieldState

    init(rootView: Content, captureState: PrivacyShieldState) {
        self.hostingController = UIHostingController(rootView: rootView)
        self.captureState = captureState
        super.init(nibName: nil, bundle: nil)
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .black
        configureSecureContainer()
    }

    func update(rootView: Content) {
        hostingController.rootView = rootView
    }

    private func configureSecureContainer() {
        secureTextField.translatesAutoresizingMaskIntoConstraints = false
        secureTextField.backgroundColor = .clear
        secureTextField.borderStyle = .none
        secureTextField.textColor = .clear
        secureTextField.tintColor = .clear
        secureTextField.autocorrectionType = .no
        secureTextField.spellCheckingType = .no
        secureTextField.isSecureTextEntry = true
        secureTextField.text = "HTVANTIX"

        view.addSubview(secureTextField)
        NSLayoutConstraint.activate([
            secureTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            secureTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            secureTextField.topAnchor.constraint(equalTo: view.topAnchor),
            secureTextField.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])

        // Force UIKit to create the secure text rendering hierarchy.
        view.layoutIfNeeded()
        secureTextField.layoutIfNeeded()

        // Do not assume `subviews.first` is the protected canvas. That can
        // select an internal wrapper on some iOS versions and make the owner's
        // screen blank. Find UIKit's secure text rendering canvas explicitly.
        guard let canvas = findSecureCanvas(in: secureTextField) else {
            installFallbackContent()
            return
        }

        protectedCanvas = canvas
        canvas.clipsToBounds = true
        canvas.backgroundColor = .clear

        addChild(hostingController)
        let hostedView = hostingController.view!
        hostedView.translatesAutoresizingMaskIntoConstraints = false
        hostedView.backgroundColor = .clear
        canvas.addSubview(hostedView)

        NSLayoutConstraint.activate([
            hostedView.leadingAnchor.constraint(equalTo: canvas.leadingAnchor),
            hostedView.trailingAnchor.constraint(equalTo: canvas.trailingAnchor),
            hostedView.topAnchor.constraint(equalTo: canvas.topAnchor),
            hostedView.bottomAnchor.constraint(equalTo: canvas.bottomAnchor)
        ])

        hostingController.didMove(toParent: self)
        captureState.secureContainerReady = true
    }

    private func findSecureCanvas(in root: UIView) -> UIView? {
        for child in root.subviews {
            let className = NSStringFromClass(type(of: child))
            if className.contains("CanvasView") || className.contains("LayoutCanvas") {
                return child
            }
            if let match = findSecureCanvas(in: child) {
                return match
            }
        }
        return nil
    }

    private func installFallbackContent() {
        addChild(hostingController)
        let hostedView = hostingController.view!
        hostedView.translatesAutoresizingMaskIntoConstraints = false
        hostedView.backgroundColor = .clear
        view.addSubview(hostedView)

        NSLayoutConstraint.activate([
            hostedView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            hostedView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            hostedView.topAnchor.constraint(equalTo: view.topAnchor),
            hostedView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])

        hostingController.didMove(toParent: self)
        captureState.secureContainerReady = false
    }
}

// MARK: - Privacy state

@MainActor
final class PrivacyShieldState: ObservableObject {
    @Published private(set) var screenCaptured = UIScreen.main.isCaptured
    @Published private(set) var appInactive = false
    @Published fileprivate var secureContainerReady = false

    private var observers: [NSObjectProtocol] = []

    init() {
        observers.append(NotificationCenter.default.addObserver(
            forName: UIScreen.capturedDidChangeNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.screenCaptured = UIScreen.main.isCaptured
        })

        observers.append(NotificationCenter.default.addObserver(
            forName: UIApplication.willResignActiveNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.appInactive = true
        })

        observers.append(NotificationCenter.default.addObserver(
            forName: UIApplication.didBecomeActiveNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.appInactive = false
            self?.screenCaptured = UIScreen.main.isCaptured
        })
    }

    deinit {
        observers.forEach(NotificationCenter.default.removeObserver)
    }

    // Only cover the LOCAL display while the app is leaving the foreground,
    // so the app-switcher snapshot is black. Never black out the owner's live
    // display merely because screen capture/share is active. The secure UIKit
    // rendering container is responsible for excluding protected content from
    // the captured output while the owner keeps seeing the app normally.
    var shouldCoverLocally: Bool {
        appInactive
    }
}

// MARK: - SwiftUI modifier

struct PrivacyShieldModifier: ViewModifier {
    @StateObject private var state = PrivacyShieldState()

    func body(content: Content) -> some View {
        ZStack {
            CaptureProtectedContainer(captureState: state) {
                content
            }
            .ignoresSafeArea()

            if state.shouldCoverLocally {
                Color.black
                    .ignoresSafeArea()
                    .zIndex(999_999)
                    .accessibilityHidden(true)
            }
        }
    }
}

extension View {
    func htvantixPrivacyShield() -> some View {
        modifier(PrivacyShieldModifier())
    }
}
