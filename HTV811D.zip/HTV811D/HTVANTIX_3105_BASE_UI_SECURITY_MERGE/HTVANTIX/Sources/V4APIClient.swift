import Foundation
import CryptoKit
import UIKit

/// Client for the deployed HIGHT API V4 backend.
/// Patch/apply logic is intentionally not part of this class.
final class V4APIClient {
    private let baseURL: URL
    private let appToken: String
    private let urlSession: URLSession

    init(baseURL: URL = BuildIdentity.baseURL, appToken: String = BuildIdentity.appToken) {
        self.baseURL = baseURL
        self.appToken = appToken
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 25
        config.timeoutIntervalForResource = 90
        config.requestCachePolicy = .reloadIgnoringLocalCacheData
        self.urlSession = URLSession(configuration: config)
    }

    private func configuredRequest(url: URL, method: String = "GET", bearer: String? = nil) throws -> URLRequest {
        guard !appToken.isEmpty, appToken != "__HTVANTIX_APP_TOKEN__" else {
            throw APIError.clientNotConfigured
        }
        var req = URLRequest(url: url)
        req.httpMethod = method
        req.setValue(appToken, forHTTPHeaderField: "X-App-Token")
        req.setValue(BuildIdentity.version, forHTTPHeaderField: "X-App-Version")
        req.setValue(BuildIdentity.buildID, forHTTPHeaderField: "X-Build-ID")
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        if let bearer, !bearer.isEmpty {
            req.setValue("Bearer \(bearer)", forHTTPHeaderField: "Authorization")
        }
        return req
    }

    private func ensure2xx(_ data: Data, _ response: URLResponse) throws {
        guard let http = response as? HTTPURLResponse else { throw APIError.malformed }
        guard (200..<300).contains(http.statusCode) else {
            let env = try? JSONDecoder().decode(APIErrorEnvelope.self, from: data)
            throw APIError.server(
                status: http.statusCode,
                code: env?.error ?? "HTTP_\(http.statusCode)",
                client: env?.client
            )
        }
    }

    func redeemKey(_ key: String) async throws -> LicenseRedeemResponse {
        let url = baseURL.appendingPathComponent("api/v4/license/redeem")
        var req = try configuredRequest(url: url, method: "POST")
        req.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")

        let deviceModel = await MainActor.run {
            UIDevice.current.model
        }

        let body: [String: String] = [
            "key": key,
            "deviceId": DeviceIdentity.id,
            "appVersion": BuildIdentity.version,
            "buildId": BuildIdentity.buildID,
            "deviceModel": deviceModel
        ]
        req.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, response) = try await urlSession.data(for: req)
        try ensure2xx(data, response)
        return try JSONDecoder().decode(LicenseRedeemResponse.self, from: data)
    }

    func createSession(licenseToken: String) async throws -> SessionResponse {
        let url = baseURL.appendingPathComponent("api/v4/session")
        var req = try configuredRequest(url: url, method: "POST", bearer: licenseToken)
        req.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")

        let body: [String: String] = [
            "deviceId": DeviceIdentity.id,
            "appVersion": BuildIdentity.version,
            "buildId": BuildIdentity.buildID
        ]
        req.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, response) = try await urlSession.data(for: req)
        try ensure2xx(data, response)
        return try JSONDecoder().decode(SessionResponse.self, from: data)
    }

    func loadClientConfig(sessionToken: String) async throws -> V4ClientConfig {
        let req = try configuredRequest(
            url: baseURL.appendingPathComponent("api/v4/client/config"),
            bearer: sessionToken
        )
        let (data, response) = try await urlSession.data(for: req)
        try ensure2xx(data, response)
        return try JSONDecoder().decode(V4ClientConfig.self, from: data)
    }

    func loadPackages(sessionToken: String) async throws -> [RemotePackage] {
        let req = try configuredRequest(
            url: baseURL.appendingPathComponent("api/v4/packages"),
            bearer: sessionToken
        )
        let (data, response) = try await urlSession.data(for: req)
        try ensure2xx(data, response)
        return try JSONDecoder().decode(PackageListResponse.self, from: data).packages
    }

    func downloadPackage(_ package: RemotePackage, sessionToken: String) async throws -> URL {
        var components = URLComponents(
            url: baseURL.appendingPathComponent(".netlify/functions/v4-download"),
            resolvingAgainstBaseURL: false
        )
        components?.queryItems = [
            URLQueryItem(name: "id", value: package.id)
        ]
        guard let url = components?.url else {
            throw APIError.malformed
        }

        let req = try configuredRequest(url: url, bearer: sessionToken)
        let (tempURL, response) = try await urlSession.download(for: req)
        guard let http = response as? HTTPURLResponse else { throw APIError.malformed }

        // URLSession follows the backend 302 redirect to the signed R2 URL.
        guard (200..<300).contains(http.statusCode) else {
            throw APIError.server(
                status: http.statusCode,
                code: "DOWNLOAD_HTTP_\(http.statusCode)",
                client: nil
            )
        }

        let data = try Data(contentsOf: tempURL)
        let hash = SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
        guard hash.caseInsensitiveCompare(package.sha256) == .orderedSame else {
            throw APIError.integrityFailed
        }
        if package.sizeBytes > 0, data.count != package.sizeBytes {
            throw APIError.integrityFailed
        }

        let fm = FileManager.default
        let docs = try fm.url(
            for: .documentDirectory,
            in: .userDomainMask,
            appropriateFor: nil,
            create: true
        )
        let dir = docs.appendingPathComponent("HTVANTIX", isDirectory: true)
        try fm.createDirectory(at: dir, withIntermediateDirectories: true)

        let finalURL = dir.appendingPathComponent(
            package.fileName.replacingOccurrences(of: "/", with: "_")
        )
        try? fm.removeItem(at: finalURL)
        do {
            try data.write(to: finalURL, options: .atomic)
        } catch {
            throw APIError.fileWriteFailed
        }
        return finalURL
    }
}
