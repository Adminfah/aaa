import Foundation

struct V4VersionState: Codable, Equatable {
    let currentVersion: String
    let minimumVersion: String
    let updateURL: String
    let message: String
    let releaseNotes: String?
    let maintenance: Bool
    let allowedBuilds: [String]
}

struct LicenseInfo: Codable, Equatable {
    let id: String?
    let status: String?
    let expiresAt: String?
    let activatedAt: String?
    let deviceBoundAt: String?
}

struct LicenseRedeemResponse: Decodable {
    let ok: Bool
    let licenseToken: String
    let license: LicenseInfo?
    let client: V4VersionState?
}

struct SessionResponse: Decodable {
    let ok: Bool
    let sessionToken: String
    let expiresAt: String
    let client: V4VersionState?
}

struct V4ClientConfig: Decodable {
    struct Item: Decodable, Identifiable, Hashable {
        let id: String
        let title: String
    }

    struct Policy: Decodable {
        let privacyShield: Bool
        let screenCaptureCover: String
        let appSwitcherCover: String
    }

    let ok: Bool
    let version: V4VersionState
    let games: [Item]
    let categories: [Item]
    let clientPolicy: Policy
}

struct LegacyLicenseResponse: Decodable {
    let ok: Bool
    let error: String?
    let redeemedAt: String?
    let durationDays: Int?
    let durationMinutes: Int?
    let expiresAt: String?
}

struct LegacyPatchListResponse: Decodable {
    let patches: [RemotePackage]
}

struct RemotePackage: Decodable, Identifiable, Hashable {
    let id: String
    let name: String
    let description: String
    let version: String
    let game: String?
    let category: String
    let fileName: String
    let sizeBytes: Int
    let sha256: String
    let createdAt: String

    private enum CodingKeys: String, CodingKey {
        case id, name, description, version, game, gameId, category
        case fileName, sizeBytes, sha256, createdAt
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = try c.decode(String.self, forKey: .id)
        name = try c.decodeIfPresent(String.self, forKey: .name) ?? "Untitled"
        description = try c.decodeIfPresent(String.self, forKey: .description) ?? ""
        version = try c.decodeIfPresent(String.self, forKey: .version) ?? "1.0"
        fileName = try c.decodeIfPresent(String.self, forKey: .fileName) ?? "patch.3105"
        sizeBytes = try c.decodeIfPresent(Int.self, forKey: .sizeBytes) ?? 0
        sha256 = try c.decodeIfPresent(String.self, forKey: .sha256) ?? ""
        createdAt = try c.decodeIfPresent(String.self, forKey: .createdAt) ?? ""

        let rawGame = try c.decodeIfPresent(String.self, forKey: .game)
            ?? c.decodeIfPresent(String.self, forKey: .gameId)
        switch rawGame?.lowercased() {
        case "freefire-th", "freefire", "ff": game = "ff"
        case "freefire-max", "freefiremax", "ffmax": game = "ffmax"
        default: game = rawGame
        }

        let rawCategory = (try c.decodeIfPresent(String.self, forKey: .category))?.lowercased()
        switch rawCategory {
        case "shoot", "visual", "skin_free", "other": category = rawCategory!
        case "main-file", "main-file-max", nil: category = "other"
        default: category = "other"
        }
    }
}

struct PackageListResponse: Decodable {
    let ok: Bool
    let packages: [RemotePackage]
}

struct APIErrorEnvelope: Decodable {
    let error: String
    let client: V4VersionState?
}

enum APIError: LocalizedError {
    case server(status: Int, code: String, client: V4VersionState?)
    case malformed
    case clientNotConfigured
    case integrityFailed
    case fileWriteFailed

    var errorDescription: String? {
        switch self {
        case .server(_, let code, _): return code
        case .malformed: return "MALFORMED_RESPONSE"
        case .clientNotConfigured: return "CLIENT_NOT_CONFIGURED"
        case .integrityFailed: return "HASH_MISMATCH"
        case .fileWriteFailed: return "FILE_WRITE_FAILED"
        }
    }
}
