import Foundation

/// Safe integration layer for the original 3105 package/transaction format.
///
/// This service intentionally resolves only this app's own data container under
/// normal iOS sandboxing. It does not use legacy container enumeration, MCM
/// access, sandbox escape code, or any other mechanism to reach another app's
/// private container. A package that targets another bundle identifier is
/// rejected as DESTINATION_NOT_ACCESSIBLE before PatchTransaction.apply starts.
enum SafeDevicePatchService {
    private static let fm = FileManager.default
    private static let packageMapKey = "HTVANTIX.Safe3105.ProjectMap.v1"
    private static let diagnosticPrefix = "[HTVANTIX][ApplyWorkflow]"

    static func apply(packageData: Data, remotePackageID: String) throws -> PatchTransactionReceipt {
        let summary = try PatchPackageCodec.inspect(packageData)
        guard !summary.isPasswordProtected else {
            throw PatchPackageError.invalidPasswordOrCorruptedPackage
        }

        let decoded = try PatchPackageCodec.decode(packageData, password: nil)
        let project = decoded.project

        guard let ownBundleID = Bundle.main.bundleIdentifier else {
            diagnosticLog(
                "Apply stage=init failed=true reason=own_bundle_identifier_unavailable"
            )
            throw PatchPackageError.destinationNotAccessible("(unknown)")
        }

        diagnosticLog(
            "Apply stage=init remotePackageID=\(remotePackageID) " +
            "projectID=\(project.id.uuidString) ownBundleID=\(ownBundleID) " +
            "rules=\(project.rules.count) directories=\(project.directories.count)"
        )

        let requestedIDs = project.allBundleIdentifiers
        diagnosticLog(
            "container resolution stage=requested count=\(requestedIDs.count) " +
            "identifiers=\(requestedIDs.joined(separator: ","))"
        )

        let roots: [String: URL]
        do {
            roots = try resolvedContainers(for: requestedIDs, ownBundleID: ownBundleID)
        } catch {
            diagnosticLog(
                "container resolution stage=failed error=\(diagnosticCode(for: error)) " +
                "ownBundleID=\(ownBundleID)"
            )
            throw error
        }

        diagnosticLog(
            "container resolution stage=completed " +
            "resolved=\(roots.count) requested=\(requestedIDs.count)"
        )
        diagnosticLog("Apply entry point=PatchTransaction.apply calling projectID=\(project.id.uuidString)")

        let receipt: PatchTransactionReceipt
        do {
            receipt = try PatchTransaction.apply(
                project: project,
                backupRoot: try backupRootURL(),
                containerResolver: { bundleID in
                    guard let root = roots[bundleID] else {
                        throw PatchPackageError.targetAppUnavailable(bundleID)
                    }
                    return root
                }
            )
        } catch {
            diagnosticLog(
                "Apply entry point=PatchTransaction.apply failed " +
                "error=\(diagnosticCode(for: error))"
            )
            throw error
        }

        diagnosticLog("Apply entry point=PatchTransaction.apply completed receiptID=\(receipt.id.uuidString)")
        storeProjectID(project.id, forRemotePackageID: remotePackageID)
        return receipt
    }

    static func restore(remotePackageID: String) throws {
        guard let projectID = storedProjectID(forRemotePackageID: remotePackageID),
              let receipt = PatchTransaction.latestReceipt(
                projectID: projectID,
                backupRoot: try backupRootURL()
              ) else {
            throw PatchPackageError.restoreFailed
        }

        guard let ownBundleID = Bundle.main.bundleIdentifier else {
            diagnosticLog(
                "Restore stage=init failed=true reason=own_bundle_identifier_unavailable"
            )
            throw PatchPackageError.destinationNotAccessible("(unknown)")
        }

        diagnosticLog(
            "Restore stage=init remotePackageID=\(remotePackageID) " +
            "projectID=\(projectID.uuidString) ownBundleID=\(ownBundleID)"
        )

        let bundleIDs = try PatchTransaction.requiredBundleIdentifiers(for: receipt)
        diagnosticLog(
            "container resolution stage=requested count=\(bundleIDs.count) " +
            "identifiers=\(bundleIDs.joined(separator: ","))"
        )

        let roots = try resolvedContainers(for: bundleIDs, ownBundleID: ownBundleID)

        try PatchTransaction.restore(
            receipt: receipt,
            containerResolver: { bundleID in
                guard let root = roots[bundleID] else {
                    throw PatchPackageError.targetAppUnavailable(bundleID)
                }
                return root
            }
        )

        removeStoredProjectID(forRemotePackageID: remotePackageID)
    }

    static func isApplied(remotePackageID: String) -> Bool {
        guard let projectID = storedProjectID(forRemotePackageID: remotePackageID),
              let backupRoot = try? backupRootURL() else { return false }
        return PatchTransaction.latestReceipt(projectID: projectID, backupRoot: backupRoot) != nil
    }

    static func removeDownloadedPackage(_ package: RemotePackage) throws {
        let root = try downloadCacheRootURL()
        let cached = root.appendingPathComponent(package.id, isDirectory: false)
        if fm.fileExists(atPath: cached.path) {
            try fm.removeItem(at: cached)
        }
    }

    /// Copies the verified download into Application Support before decoding it.
    /// This avoids depending on the lifetime of a temporary URL returned by URLSession.
    static func stageVerifiedDownload(_ source: URL, package: RemotePackage) throws -> URL {
        let root = try downloadCacheRootURL()
        let target = root.appendingPathComponent(package.id, isDirectory: false)
        if fm.fileExists(atPath: target.path) {
            try fm.removeItem(at: target)
        }
        try fm.copyItem(at: source, to: target)
        return target
    }

    private static func resolvedContainers(for bundleIDs: [String], ownBundleID: String) throws -> [String: URL] {
        var roots: [String: URL] = [:]
        for bundleID in bundleIDs {
            roots[bundleID] = try resolveAuthorizedContainer(bundleID: bundleID, ownBundleID: ownBundleID)
        }
        return roots
    }

    private static func resolveAuthorizedContainer(bundleID: String, ownBundleID: String) throws -> URL {
        diagnosticLog(
            "container resolution step=start requested=\(bundleID) own=\(ownBundleID) " +
            "policy=self_only_mode"
        )

        // 1. Validate bundle identifier format
        let canonical: String
        do {
            canonical = try PatchPathValidator.canonicalBundleIdentifier(bundleID)
        } catch {
            diagnosticLog(
                "container resolution step=failed stage=bundle_id_validation " +
                "requested=\(bundleID) error=\(diagnosticCode(for: error))"
            )
            throw error
        }

        guard canonical == bundleID else {
            diagnosticLog(
                "container resolution step=failed stage=bundle_id_canonical " +
                "requested=\(bundleID) canonical=\(canonical) " +
                "error=\(PatchPackageError.invalidBundleIdentifier.diagnosticCode)"
            )
            throw PatchPackageError.invalidBundleIdentifier
        }
        diagnosticLog(
            "container resolution step=passed stage=bundle_id_validation " +
            "requested=\(bundleID) canonical=\(canonical)"
        )

        // 2. Enforce self-only container policy
        guard bundleID == ownBundleID else {
            diagnosticLog(
                "container resolution step=failed stage=policy_check " +
                "policy=self_only_mode requested=\(bundleID) own=\(ownBundleID) " +
                "reason=bundle_id_mismatch"
            )
            diagnosticLog(
                "container resolution step=rejected " +
                "requested=\(bundleID) own=\(ownBundleID) " +
                "error=\(PatchPackageError.destinationNotAccessible(bundleID).diagnosticCode) " +
                "policy=self_only_mode"
            )
            throw PatchPackageError.destinationNotAccessible(bundleID)
        }
        diagnosticLog(
            "container resolution step=passed stage=policy_check " +
            "policy=self_only_mode bundleID=\(bundleID)"
        )

        // 3. Resolve and validate container path
        let root = PatchPathValidator.canonicalFileURL(
            URL(fileURLWithPath: NSHomeDirectory(), isDirectory: true)
        )
        return try validateAccessibleDestination(root, bundleID: bundleID)
    }

    private static func validateAccessibleDestination(_ root: URL, bundleID: String) throws -> URL {
        var isDirectory = ObjCBool(false)
        let exists = fm.fileExists(atPath: root.path, isDirectory: &isDirectory)
        let readable = fm.isReadableFile(atPath: root.path)
        let writable = fm.isWritableFile(atPath: root.path)

        diagnosticLog(
            "container resolution step=access_check " +
            "path=\(root.path) exists=\(exists) " +
            "isDirectory=\(isDirectory.boolValue) readable=\(readable) writable=\(writable)"
        )

        guard exists, isDirectory.boolValue, readable, writable else {
            diagnosticLog(
                "container resolution step=failed stage=access_check " +
                "bundleID=\(bundleID) exists=\(exists) isDir=\(isDirectory.boolValue) " +
                "readable=\(readable) writable=\(writable) " +
                "error=\(PatchPackageError.destinationNotAccessible(bundleID).diagnosticCode)"
            )
            throw PatchPackageError.destinationNotAccessible(bundleID)
        }

        diagnosticLog(
            "container resolution step=passed stage=access_check " +
            "bundleID=\(bundleID) path=\(root.path)"
        )
        return root
    }

    private static func backupRootURL() throws -> URL {
        let base = try fm.url(
            for: .applicationSupportDirectory,
            in: .userDomainMask,
            appropriateFor: nil,
            create: true
        )
        let root = base
            .appendingPathComponent("HTVANTIX", isDirectory: true)
            .appendingPathComponent("3105Backups", isDirectory: true)
        try fm.createDirectory(at: root, withIntermediateDirectories: true)
        return root
    }

    private static func downloadCacheRootURL() throws -> URL {
        let base = try fm.url(
            for: .applicationSupportDirectory,
            in: .userDomainMask,
            appropriateFor: nil,
            create: true
        )
        let root = base
            .appendingPathComponent("HTVANTIX", isDirectory: true)
            .appendingPathComponent("3105Packages", isDirectory: true)
        try fm.createDirectory(at: root, withIntermediateDirectories: true)
        return root
    }

    private static func storedProjectID(forRemotePackageID packageID: String) -> UUID? {
        let map = UserDefaults.standard.dictionary(forKey: packageMapKey) as? [String: String] ?? [:]
        guard let raw = map[packageID] else { return nil }
        return UUID(uuidString: raw)
    }

    private static func storeProjectID(_ projectID: UUID, forRemotePackageID packageID: String) {
        var map = UserDefaults.standard.dictionary(forKey: packageMapKey) as? [String: String] ?? [:]
        map[packageID] = projectID.uuidString
        UserDefaults.standard.set(map, forKey: packageMapKey)
    }

    private static func removeStoredProjectID(forRemotePackageID packageID: String) {
        var map = UserDefaults.standard.dictionary(forKey: packageMapKey) as? [String: String] ?? [:]
        map.removeValue(forKey: packageID)
        UserDefaults.standard.set(map, forKey: packageMapKey)
    }

    private static func diagnosticLog(_ message: String) {
        NSLog("%@ %@", diagnosticPrefix, message)
    }

    private static func diagnosticCode(for error: Error) -> String {
        if let packageError = error as? PatchPackageError {
            return packageError.diagnosticCode
        }
        return String(describing: type(of: error))
    }
}
