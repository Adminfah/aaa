# Third-party notices and credits

3105 is developed and designed by YangJiii. It also incorporates ideas, formats, research, or implementation foundations from the following community work.

| Project/person | Contribution acknowledged by 3105 | Upstream |
| --- | --- | --- |
| 0xjohnnydev and FilzaSlop contributors | MHA-C2 app-data discovery and sandbox-escape foundation | FilzaSlop |
| CrazyMind90 | FilzaSlop sandbox-escape foundation | GitHub profile |
| LeminLimez and contributors | Pocket Poster, Nugget, and the `.tendies` package format | Pocket-Poster |
| forcequitOS | `bad_query` research | GitHub profile |
| opa334 and Dopamine contributors | Kernel-exploit research foundation | Dopamine |

Original portions of 3105 are distributed under GPL-3.0. Pocket-Poster also publishes a GPL-3.0 license in its upstream repository. FilzaSlop did not expose a repository license through GitHub when this notice was prepared. Review each upstream project and its current terms before redistributing derived code.

The 3105 license applies only to material for which the project owner has the right to grant that license. This file provides attribution; it does not replace upstream copyright or license notices and does not relicense third-party material.
